// $ROOT$ project main.go
package main

import (
	"fmt"
)

func main() {
	fmt.Println("Hello World!")
}
