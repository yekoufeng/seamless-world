// $ROOT$ project $ROOT$.go
package $ROOT$
