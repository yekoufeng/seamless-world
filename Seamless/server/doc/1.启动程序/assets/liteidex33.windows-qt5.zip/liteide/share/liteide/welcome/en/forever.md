<!-- Forever -->

Forever
=======
## liteide
天行健，君子以自强不息。地势坤，君子以厚德载物。

![](images/liteide.png)

## logo 

![](images/liteide400.png)

## @_@
佛祖问阿难：你有多喜欢这少女? 阿难说：我愿化身石桥，受五百年风吹，五百年日晒，五百年雨打，但求此少女从桥上走过。


## with you

![](images/flamingo.png)

## forever
![](images/forever.png)

